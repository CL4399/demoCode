const { Bot } = require("mirai-js");
const bot = new Bot();

module.exports = bot;
