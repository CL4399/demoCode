export interface Article {
    ID: string;
    Title: string;
    Preview: string;
    Content: string;
}

export interface Like{
    likes: number
}