# Web003Gin-01_gingormtutorials
Code and text version of the tutorial on Gin, Gorm, Golang, Vue, Redis, MySQL, InkkaPlumChannel. | InkkaPlum频道的Gin, Gorm, Vue, Redis, MySQL教程的代码和文字版教程。

这是[B站InkkaPlum频道](https://space.bilibili.com/290859233), 知乎[Inkka Plum](https://www.zhihu.com/people/instead-opt)的Go+Gin+Gorm+Vue+Redis+MySQL教程对应的项目源码和课件(文字版教程), 具体教程/操作方法请查看文件[Gin感情参考書](Gin感情参考書(课件).md)

# 注意:

觉得有帮助, 请给一个Star, 并且别忘了关注B站频道知乎和GitHub, 给一个三连, 感谢!

本教程中全部文字版教程和代码为 B 站: [InkkaPlum 频道](https://space.bilibili.com/290859233) 和知乎: [Inkka Plum](https://www.zhihu.com/people/instead-opt)的相关教程所用, 仅供学习。

不得二次用于任何机构/个人再次录制 Go / Gin / Gorm / Redis / MySQL / Vue 或其它任何语言, 框架, 架构, 工具等等教程中。

但是非常欢迎修改案例项目或者添加更多功能。这个项目只是实现了基本的功能, 也有很多可扩充、完善的点。

此外, 下文有任何问题或者需要改进的点, 请联系 UP 主。

以上就是全部内容, 如果有任何问题, 欢迎私信UP主反馈!

以上 祝学习成功!

Inkka Plum
